from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('register/', views.register, name='register'),
    path('otpVerify/', views.otpVerify, name='otpVerify'),
    path('oauth_Verification/', views.oauth_Verification, name='oauth_Verification'),
    path('createPassword/', views.createPassword, name='createPassword'),
    path('home/', views.home, name='home'),
    path('login/', views.login, name='login'),
]