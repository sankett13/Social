from django.db import models
from django.utils import timezone

# Create your models here.
class User(models.Model):
    email = models.EmailField()
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    is_active = models.BooleanField(default=True)
    is_SuperUser = models.BooleanField(default=False)
    joined_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f'{self.username} joined on {self.joined_at}'
    

