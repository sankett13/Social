from django.shortcuts import render ,redirect
from django.http import HttpResponse
from django.template import loader
from django.views.decorators.csrf import csrf_exempt
from django.core.mail import send_mail
from django.conf import settings
from .forms import SimpleCaptchaForm
from django.contrib.auth.decorators import login_required
from allauth.socialaccount.models import SocialAccount
import random, string
from .models import User 
from django.contrib.auth.hashers import make_password, check_password
import hashlib


def generate_Otp():
    return str(random.randint(1000,9999))

def usenameGenerator():
    random_digits = ''.join(random.choices(string.digits, k=3))
    random_letters = ''.join(random.choices(string.ascii_letters, k=3))

    while User.objects.filter(username=f"Anon{random_digits}{random_letters}").exists():
        random_digits = ''.join(random.choices(string.digits, k=3))
        random_letters = ''.join(random.choices(string.ascii_letters, k=3))

    username = f"Anon{random_digits}{random_letters}"
    return username


def send_Email(email,subject,message):
    email_from = settings.EMAIL_HOST_USER
    recipient_list = [email]
    send_mail(subject, message, email_from, recipient_list,fail_silently=False)


@login_required
def index(request):
    print(request.user.is_authenticated)
    socialAcc = SocialAccount.objects.filter(user=request.user,provider='google').first()
    email = socialAcc.extra_data['email']
    print(email)
    return (HttpResponse("Hello, world. You're at the main index."))


@csrf_exempt
def register(request):
    if request.method == 'GET':
        captchaForm = SimpleCaptchaForm()
        template = loader.get_template('Register.html')
        return render(request, 'Register.html', {'captchaForm': captchaForm})
    elif request.method == 'POST':
        captchaForm = SimpleCaptchaForm(request.POST)
        if captchaForm.is_valid():
            print("Valid Captcha")    
            email = request.POST['email']
            
            if User.objects.filter(email=hashlib.sha256(email.encode('utf-8')).hexdigest()).exists():
                return HttpResponse("Email Already Exists")

            otp = generate_Otp()
            print(otp)
            subject = "Your OTP Verfification Code"
            message = f"Your OTP is {otp}"
            send_Email(email,subject,message)

            request.session['email'] = email
            request.session['otp'] = otp
            template = loader.get_template('otpVerify.html')
            return HttpResponse(template.render())
        else:
            return HttpResponse("Invalid Captcha")



@csrf_exempt
def otpVerify(request):
    if request.method == 'POST'or request.method == 'GET':
        req_method = request.method
        otp = request.POST['otp']
        print(otp)
        if otp == request.session['otp']:
            username = usenameGenerator()
            request.session['username'] = username
            subject = "OTP Verification Successful"
            message = f"Welcome {username}"
            email = request.session['email']
            send_Email(email,subject,message)
            return redirect('createPassword')
        else:
            return HttpResponse("OTP is InValid")
    return HttpResponse(f"Your OTP is {request.session['otp']}")


@csrf_exempt
def createPassword(request):
    
    if request.method == 'POST':
        password = request.POST['password']
        confirmpassword = request.POST['confirmpassword']
        if password == confirmpassword:
            username = request.session['username']
            email = request.session['email']
            hashed_email = hashlib.sha256(email.encode('utf-8')).hexdigest()
            hased_password = make_password(password)
            user = User(email=hashed_email,username=username,password=hased_password)
            user.save()
            print(username)
            

            return redirect('home')
        else:
            return HttpResponse("Password is Invalid")
    
    if request.method == 'GET':
        # context = {username: request.session['username']}
        return render(request, 'createPass.html', {"username": request.session['username']})
    


@csrf_exempt
def oauth_Verification(request):
    if request.method == 'GET':
        socialAcc = SocialAccount.objects.filter(user=request.user,provider='google').first()
        email = socialAcc.extra_data['email']
        if User.objects.filter(email=hashlib.sha256(email.encode('utf-8')).hexdigest()).exists():
            return HttpResponse("Email Already Exists")
        print(email)
        otp = generate_Otp()
        subject = "Your OTP Verfification Code"
        message = f"Your OTP is {otp}"
        send_Email(email,subject,message)
        request.session['email'] = email
        request.session['otp'] = otp

        captchaform = SimpleCaptchaForm()
        return render(request, 'oauth_Verification.html', {'captchaForm': captchaform})

    elif request.method == 'POST':
        print("POST")
        captchaform = SimpleCaptchaForm(request.POST)
        print(captchaform.is_valid())
        if captchaform.is_valid():
            if request.session['otp'] == request.POST['otp']:
                username = usenameGenerator()
                request.session['username'] = username
                subject = "OTP Verification Successful"
                message = f"Welcome {username}"
                email = request.session['email']
                send_Email(email,subject,message)
                return redirect('createPassword')
            else:
                return HttpResponse("OTP is InValid")
           
        else:
            print("Captcha is Invalid")
            return HttpResponse("Captcha is Invalid")
            

@csrf_exempt
def login(request):
    if request.method == 'GET':
        return render(request, 'login.html')
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        user = User.objects.filter(email=hashlib.sha256(email.encode('utf-8')).hexdigest()).first()
        if user:
            if check_password(password,user.password):
                return redirect('home')
            else:
                return HttpResponse("Password is Invalid")
        else:
            return HttpResponse("Email is Invalid")
        
        
           
        
    
def home(request):
    return render(request, 'home.html')




